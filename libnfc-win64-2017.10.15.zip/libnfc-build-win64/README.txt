put libnfc.dll into: c:\windows\system32

